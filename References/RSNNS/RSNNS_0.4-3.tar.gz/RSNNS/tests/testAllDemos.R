#library(RSNNS)
#
#res <- demo(package="RSNNS")$results
#
#allDemos <- res[, which(colnames(res)=="Item")]
#
#for(currDemo in allDemos) {
#  #print(paste("Running ", currDemo, "\n",sep=""))
#  demo(currDemo, character.only=TRUE, ask=FALSE)
#}
